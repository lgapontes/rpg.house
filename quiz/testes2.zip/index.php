<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="utf-8">
    <title>quiz</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Rancho&display=swap" rel="stylesheet">
		<link rel="icon" href="img/favicon.png">
    <style>

      body {
        background-color: #00ff00;
        font-family: 'Rancho', cursive;
        color: #405060;
      }

      div.paper {
        width: 360px;
        height: 400px;
        position: fixed;
        margin: 0 auto;
        background-image: url(img/paper.png);
        background-repeat: no-repeat;
        background-size: 360px 400px;
        padding-bottom: 50px;
      }

      span.titulo {
        font-size: 2.2em;
        text-align: center;
        width: 100%;
        display: block;
        margin-top: 40px;
      }

      div.box {
        margin: 10px auto 0 auto;
        width: 200px;
        font-size: 1.8em;
      }

      div.box::after {
        content: '';
        clear: both;
        height: 0;
        display: block;
      }

      div.box span.numero {
        background-color: #ddddff;
        width: 30%;
        display: block;
        float: left;
        text-align: center;
      }

      div.box span.valor {
        background-color: #eeeeff;
        color: #303090;
        margin-left: 2px;
        width: 65%;
        float: left;
        padding: 0 0 0 5px;
      }

    </style>
  </head>
  <body>

    <div class="paper">

      <?php

      select codigo maior_codigo from posts maior where maior.codigo = codigo and oist

nvl(select max(codigo) from posts where usuario = 'sirlockee' and corte = 1,0);

        error_reporting(E_ERROR | E_PARSE);
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

        $conexao = new mysqli('linu.com.br','linuc318_sir','linuX321','linuc318_sirlockee_db');
        mysqli_set_charset(self::$conexao, "utf8");

        $query = $conexao->prepare("");
        $query->bind_param("i",$codigoUsuario);
        $query->execute();
        $query->store_result();
        $query->bind_result($codigo, $descricao);

        $perguntas = array();

        if ($query->num_rows > 0) {
            while ($query->fetch()) {
                $pergunta = new Pergunta($descricao);
                $pergunta->setCodigo($codigo);
                array_push($perguntas,$pergunta);
            }
        }

        return $perguntas;




      <span class="titulo">Teste #3</span>
      <div class="box">
        <span class="numero">#1</span>
        <span class="valor">2</span>
      </div>
    </div>

    <?php

    <script>
    </script>

  </body>
</html>
