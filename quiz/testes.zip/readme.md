User ID:
drjTU8TWQO29NRoCdbEvCQ

Channel ID:
UCdrjTU8TWQO29NRoCdbEvCQ

API Key Google:
AIzaSyB6hsJq9upTevgRKl2geF91gHlvbDGiXZA

Doc:
https://developers.google.com/youtube/v3/live/docs/liveChatMessages
https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_indexof

Node e NPM:
C:\dev\nodejs
npm config set proxy http://xbwz:vou29laR@inet-sys.gnet.petrobras.com.br:804
npm config set https_proxy https://xbwz:vou29laR@inet-sys.gnet.petrobras.com.br:804
npm install youtube-live-chat

Banco:
linuc318_sirlockee_db
User: linuc318_sir
Senha: linuX321
